package com.demo.spring.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.demo.spring.CustomerRepository;
import com.demo.spring.model.Customer;
@RestController
public class WebController {
    
	@Autowired
	CustomerRepository repo;
    
    @GetMapping("/customers")
    public List<Customer> getCustomers() {
    	return repo.findAll();
    }
    
    @PostMapping("/customers")
    public void addCust(@RequestBody Customer c) {
    	repo.save(c);
    }
    
    @GetMapping("/customers/{id}")
    public Optional<Customer> getCustomerById(@PathVariable("id") Long id) {
    	return repo.findById(id);
    }
    
    @PostMapping("/customers/delete/{id}")
    public List deleteCustomers(@PathVariable("id") Long id) {
    	repo.deleteById(id);
    	return repo.findAll();
    }
    
    @PostMapping("/customers/update")
    public void updateCustomers( @RequestBody Customer c) {
    	repo.save(c);
    }
    
}