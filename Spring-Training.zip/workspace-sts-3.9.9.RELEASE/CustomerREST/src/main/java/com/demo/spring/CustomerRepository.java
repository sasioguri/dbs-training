package com.demo.spring;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.spring.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long>{

}
