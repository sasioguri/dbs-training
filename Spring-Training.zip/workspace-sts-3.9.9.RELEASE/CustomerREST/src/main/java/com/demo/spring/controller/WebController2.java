/*package com.demo.spring.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.spring.CustomerRepository;
import com.demo.spring.dao.CustomerDAO;
import com.demo.spring.model.Customer;
@RestController
public class WebController2 {
    
	@Autowired
	CustomerRepository repo;
	
    //@Autowired
    //CustomerDAO customerDao;
    
    @GetMapping("/customers")
    public List getCustomers() {
        return customerDao.list();
    }
    @GetMapping("/customers/{id}")
   public Customer getCustomerById(@PathVariable("id") Long id) {
       Customer c = customerDao.getCustomer(id);
       return c;
   }
    
    @PostMapping("/customers")
    public Customer createCustomer(@RequestBody Customer c) {
    	customerDao.create(c);
    	return c;
    }
    
    @PostMapping("/customers/delete/{id}")
    public List deleteCustomers(@PathVariable("id") Long id) {
    	customerDao.delete(id);
    	return customerDao.list();
    }
    @PostMapping("/customers/update/{id}")
    public Customer updateCustomers(@PathVariable("id") Long id, @RequestBody Customer c) {
    	customerDao.update(id, c);
    	return c;
    }
    
}*/