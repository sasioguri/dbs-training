/*package com.demo.spring.dao;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.stereotype.Component;

import com.demo.spring.model.Customer;
@Component
public class CustomerDAO {
   private static List<Customer> customers;
   {
       customers = new ArrayList();
       customers.add(new Customer((long)101, "abc", "def", "abcdef@gmail.com", "2468236", new Date()));
       customers.add(new Customer((long)102, "ghi", "jkl", "ghijkl@gmail.com", "2468236", new Date()));
       customers.add(new Customer((long)103, "mno", "pqr", "mnopqr@gmail.com", "2468236", new Date()));
       customers.add(new Customer((long)104, "stu", "vwx", "stuvwx@gmail.com", "2468236", new Date()));
   }
   public List list() {
       return customers;
   }
   public Customer create(Customer customer) {
       customers.add(customer);
       return customer;
   }
   public Customer getCustomer(Long id) {
       for(Customer c: customers) {
          if(c.getId().equals(id)) {
              return c;
          }
      }
      return null;
   }
   public Long delete(Long id) {
      for(Customer c: customers) {
          if(c.getId().equals(id)) {
              customers.remove(c);
              return id;
          }
      }
      return null;
  }
   public Customer update(Long id, Customer customer) {
       for(Customer c : customers) {
           if(c.getId().equals(id)) {
               customer.setId(c.getId());
               customers.remove(c);
               customers.add(customer);
               return customer;
           }
       }
       return null;
   }
}
*/