package com.demo.entity;


import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="MYDEPT")
public class Dept {
	
	@Id
	@Column(name="DNO")
	private int deptId;
	
	@Column(name="DNAME")
	private String name;
	
	@Column(name="MANAGER")
	private String managerName;
	
	@OneToMany
	@JoinColumn(name="DNO")
	Set<Emp> emps = new HashSet<>();
	
	
	/*for(Emp e : emps) {
		System.out.println(e);
	}
	Iterator<Emp> i = emps.iterator();
	
	while(i.hasNext()) {
		System.out.println(i.next());
	}*/
	
	
	public Set<Emp> getEmps() {
		return emps;
	}

	public void setEmps(Set<Emp> emps) {
		this.emps = emps;
	}

	public Dept () {
		
	}

	public Dept(int deptId, String name, String managerName) {
		this.deptId = deptId;
		this.name = name;
		this.managerName = managerName;
	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	
}

