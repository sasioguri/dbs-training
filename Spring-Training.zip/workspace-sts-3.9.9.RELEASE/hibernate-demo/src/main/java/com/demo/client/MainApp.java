package com.demo.client;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.demo.entity.Dept;
import com.demo.entity.Emp;

public class MainApp {
	public static void main(String[] args) {
		Configuration cfg = new Configuration().configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		try {
			
			/*Emp e = new Emp(230, "Johnss", "Bangalore", 45000);
			session.persist(e);*/
			
			Dept dept = session.get(Dept.class, 30);
			Emp e1 = new Emp(201,"Vijay","Hampi", 34000);
			Emp e2 = new Emp(202,"Rakesh","Bangalore", 38000);
			
			e1.setDept(dept);
			e2.setDept(dept);
			
			session.persist(e1);
			session.persist(e2);
			
			tx.commit();
		} catch (HibernateException e) {
			tx.rollback();
		} finally {
			session.close();
			sf.close();
		}
	}
}
