package com.demo.spring;


import org.springframework.stereotype.Repository;

@Repository
public class EmpDaoMockImpl implements EmpDao{

	public void save() {
		// TODO Auto-generated method stub
		System.out.println("Emp Saved  " );
	}
	
}
