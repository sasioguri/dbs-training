package com.demo.spring;

public interface EmpDao {
	public void save();
}
