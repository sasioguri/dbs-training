package com.demo.spring;

public class Participant {
	private LunchBox lunchbox;
	public Participant() {
		
	}
	public LunchBox getLunchbox() {
		return lunchbox;
	}
	public void setLunchbox(LunchBox lunchbox) {
		this.lunchbox = lunchbox;
	}

	public void getlunch() {
		System.out.println(lunchbox.getItems());
	}
}
