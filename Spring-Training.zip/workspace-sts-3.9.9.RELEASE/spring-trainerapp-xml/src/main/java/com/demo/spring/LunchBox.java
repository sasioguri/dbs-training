package com.demo.spring;

import java.awt.List;
import java.util.ArrayList;
import java.util.Iterator;

public class LunchBox {
	private ArrayList<Item> items;
	public LunchBox() {
		
	}
	public ArrayList<Item> getItems() {
		return items;
	}
	public void setItems(ArrayList<Item> items) {
		this.items = items;
	}
	
	public void display() {
		Iterator<Item> it = items.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}
	
}
