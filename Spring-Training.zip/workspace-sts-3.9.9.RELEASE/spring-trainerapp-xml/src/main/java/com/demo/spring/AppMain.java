package com.demo.spring;

import java.util.Iterator;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;

public class AppMain {
	public static void main(String[] args) {
		//BeanFactory factory = new XmlBeanFactory(new FileSystemResource("C:\\Users\\Abride Solutions\\Documents\\workspace-sts-3.9.9.RELEASE\\spring-app-xml\\src\\main\\resources\\context.xml"));
		//Mail mail=(Mail)factory.getBean("mymail");
		ApplicationContext ctx = new ClassPathXmlApplicationContext("context.xml");
		/*LunchBox lunchbox = (LunchBox)ctx.getBean("mylunchbox");
		lunchbox.display();
		Participant participant = (Participant)ctx.getBean("myparticipant");
		participant.getlunch();*/
		Trainer trainer = (Trainer)ctx.getBean("mytrainer");
		trainer.display();
}
}
