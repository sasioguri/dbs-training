package com.demo.spring;

import java.util.ArrayList;
import java.util.Iterator;

public class Trainer {
	private ArrayList<Participant> list;
	public Trainer() {
		
	}
	public ArrayList<Participant> getList() {
		return list;
	}
	public void setList(ArrayList<Participant> list) {
		this.list = list;
	}
	public void display() {
		Iterator<Participant> it = list.iterator();
		while(it.hasNext()) {
			System.out.println("Participant" + it.next().getLunchbox().getItems());
		}
	}
	
}
