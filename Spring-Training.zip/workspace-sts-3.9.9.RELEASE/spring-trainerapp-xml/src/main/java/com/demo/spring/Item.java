package com.demo.spring;

public class Item {
	private String taste;
	private String name;
	public Item() {
		
	}
	public String getTaste() {
		return taste;
	}
	public void setTaste(String taste) {
		this.taste = taste;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Item [taste=" + taste + ", name=" + name + "]";
	}
	
}
