package com.demo.spring;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
@Component
public class SuppReqDataValidator implements Validator {
    @Override
    public boolean supports(Class<?> clazz) {
        return clazz.equals(SuppRequest.class);
    }
    @Override
    public void validate(Object target, Errors errors) {
        // TODO Auto-generated method stub
        SuppRequest e=(SuppRequest)target;
        if(e.getEmail().isEmpty())
        {
            errors.rejectValue("email", "invalid email", "email cant be empty");
        }
        if(e.getProblem().isEmpty())
        {
            errors.rejectValue("problem", "invalid problem", "problem cant be empty");
        }
    }
}