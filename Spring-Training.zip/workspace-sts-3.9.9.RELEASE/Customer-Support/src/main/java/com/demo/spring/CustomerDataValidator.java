package com.demo.spring;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
@Component
public class CustomerDataValidator implements Validator {
    @Override
    public boolean supports(Class<?> clazz) {
        return clazz.equals(Customer.class);
    }
    @Override
    public void validate(Object target, Errors errors) {
        // TODO Auto-generated method stub
        Customer e=(Customer)target;
        if(e.getFirstname().isEmpty())
        {
            errors.rejectValue("firstname", "invalid firstname", "first name cannot be empty");
        }
      if(e.getLastname().isEmpty())
          errors.rejectValue("lastname", "invalid Lastname", "first name cannot be empty");
      if(e.getPhonenumber().length()<10)
      {
          errors.rejectValue("phonenumber", "invalid Phone number", "Must have length 10");
      }
    }
}