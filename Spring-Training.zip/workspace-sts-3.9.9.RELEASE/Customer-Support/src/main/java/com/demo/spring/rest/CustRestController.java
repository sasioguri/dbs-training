package com.demo.spring.rest;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.spring.Customer;
import com.demo.spring.jpa.CustJpaRepository;
import com.demo.spring.jpa.SuppJpaRepository;

@RestController
@RequestMapping("/cust")
public class CustRestController {
	
	@Autowired
	CustJpaRepository cr;
	
	@Autowired
	SuppJpaRepository sr;
	
	@GetMapping(path="/find/{mail}", 
			produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public ResponseEntity findCust(@PathVariable("mail") String mail) {
		Optional<Customer> o = cr.findById(mail);
		System.out.println("customer found");
		if(o.isPresent()) {
			return ResponseEntity.ok(o.get());
		}
		else {
			return ResponseEntity.status(404).build();
		}
	}
	
	@PostMapping(path="/save", 
			produces = {MediaType.TEXT_XML_VALUE}, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> saveCust(@RequestBody Customer c) {
		if(cr.existsById(c.getEmail())) {
			return ResponseEntity.ok("Customer exists with mail " + c.getEmail());
		} else {
			cr.save(c);
			return ResponseEntity.ok("Customer saved with mail " + c.getEmail());
		}
	}
}
