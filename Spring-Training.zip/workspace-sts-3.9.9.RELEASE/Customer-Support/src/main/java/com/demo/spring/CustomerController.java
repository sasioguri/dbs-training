package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.demo.spring.jpa.CustJpaRepository;
import com.demo.spring.jpa.SuppJpaRepository;
/*import com.demo.spring.CustomerDataValidator;
import com.demo.spring.SuppReqDataValidator;*/

@Controller
public class CustomerController {
	
	@Autowired
	SuppJpaRepository supprepo;
	@Autowired
	CustJpaRepository custrepo;
	@Autowired
	CustomerDataValidator validator;
	@Autowired
	SuppReqDataValidator validator1;
	
	@RequestMapping(path = "/index", method = RequestMethod.GET)
    public String loadIndexPage()
    {
        return "index";
    }
	
	@RequestMapping(path = "/check" ,method = RequestMethod.POST)
	public ModelAndView checkCustomer(@ModelAttribute("suppRequest") SuppRequest suppRequest, BindingResult errors) {
		ModelAndView m = new ModelAndView();
		validator1.validate(suppRequest, errors);
        
        
		boolean status = false;
		String name = "";
		Iterable<Customer> list = custrepo.findAll();
		for(Customer customer:list) {
			if(suppRequest.getEmail().equals(customer.getEmail())) {
				status = true;
				name = customer.getFirstname()+customer.getLastname();
			}
		}
		if (errors.hasErrors()) {
            m.setViewName("index");
        }
		else {
		if(status) {
			supprepo.save(suppRequest);
			m.setViewName("response");
			m.addObject("email",suppRequest.getEmail() );
		}
		else {
			supprepo.save(suppRequest);
			m.setViewName("register");
			
		}
		}
		return m;
	}
	@RequestMapping(path = "/registration", method = RequestMethod.GET)
    public String getSecondPage(Model model) {
        Customer e = new Customer();
        model.addAttribute("suppRequest", e);
        return "registration";
    }
	
	@RequestMapping(path = "/check", method = RequestMethod.GET)
    public String getFirstPage(Model model) {
        SuppRequest e = new SuppRequest();
    
        model.addAttribute("suppRequest", e);
        return "index";
    }
	
	@RequestMapping(path="/registration",method=RequestMethod.POST)
	public ModelAndView processForm(@ModelAttribute("suppRequest") Customer e, BindingResult errors) {
		ModelAndView m = new ModelAndView();
		validator.validate(e, errors);
        if (errors.hasErrors()) {
            m.setViewName("registration");
        }
        else {
		custrepo.save(e);
		m.setViewName("response");
        }
		return m;

	}
}
