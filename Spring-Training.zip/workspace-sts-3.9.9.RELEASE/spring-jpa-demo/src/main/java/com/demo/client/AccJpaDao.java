package com.demo.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.demo.entity.Account;
import com.demo.entity.Customer;


@Repository("jpa-app")
@Transactional
public class AccJpaDao implements BankDao{
	
	@PersistenceContext
	private EntityManager em;
	
	public String saveAcc(Account e) {
		em.persist(e);
		return "account saved successfully";
	}
	
	public String saveCust(Customer e) {
		em.persist(e);
		return "customer saved successfully";
	}
	
	public void removeAcc(int id) {
		em.remove(id);
	}
	public void removeCust(int id) {
		Account acc = findAcc(id);
		if(acc.getBalance() == 0)
			removeAcc(id);
		em.remove(id);
	}
	public Account findAcc(int id) {
		Account acc = em.find(Account.class, id);
		return acc;
	}
	public Customer findCust(int id) {
		Customer cust = em.find(Customer.class, id);
		return cust;
	}
	
	/*public List<Account> showAccounts() {
		List<Account> acc = new List<Account>();
		
	}*/
}
