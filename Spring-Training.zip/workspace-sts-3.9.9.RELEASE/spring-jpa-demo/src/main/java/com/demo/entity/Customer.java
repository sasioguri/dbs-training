package com.demo.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;


@Entity
@Table(name="CUSTOMER")
public class Customer {
	@Id
	@Column(name="CUSTID")
	private int customerId;
	@Column(name="CUSTNAME")
	private String customerName;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="CUSTID")
	Set<Account> accounts = new HashSet<>();
	

	public Customer() {
		
	}
	public Customer(int customerId, String customerName, Set<Account> accounts) {
		this.customerId = customerId;
		this.customerName = customerName;
		this.accounts = accounts;
	}
	/*public Customer(int customerId, String customerName) {
		this.customerId = customerId;
		this.customerName = customerName;
	}*/

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	
	
}
