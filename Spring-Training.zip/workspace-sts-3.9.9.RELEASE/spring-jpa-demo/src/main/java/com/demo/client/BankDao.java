package com.demo.client;

import com.demo.entity.Customer;

public interface BankDao {
	public String saveCust(Customer c);
}
