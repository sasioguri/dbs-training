package com.demo.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.entity.Account;
import com.demo.entity.Customer;
import com.demo.service.BankService;
import com.demo.spring.JpaConfig;

public class SpringJpaMain {
	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(JpaConfig.class);
		BankService dao = (BankService)ctx.getBean("bankService");
		//System.out.println(dao.saveCust(new Customer(102,"Akhila")));
		//System.out.println(dao.saveAcc(new Account(201,300000, dao.findCust(101))));
		System.out.println(dao.addCustomer(106,"sasi",2000));
	}
}
