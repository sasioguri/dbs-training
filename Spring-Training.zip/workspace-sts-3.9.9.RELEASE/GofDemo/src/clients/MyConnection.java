package clients;

public interface MyConnection {

}
