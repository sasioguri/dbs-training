package com.demo.app.impl;

public class OracleDbImpl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
