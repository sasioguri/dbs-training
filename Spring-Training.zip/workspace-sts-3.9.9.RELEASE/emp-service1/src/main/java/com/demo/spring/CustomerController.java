package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.demo.spring.jpa.CustJpaRepository;
import com.demo.spring.jpa.SuppJpaRepository;

@Controller
public class CustomerController {
	
	@Autowired
	SuppJpaRepository supprepo;
	@Autowired
	CustJpaRepository custrepo;
	
	@RequestMapping(path = "/check" ,method = RequestMethod.POST)
	public ModelAndView checkCustomer(@ModelAttribute("suppRequest") SuppRequest suppRequest) {
		ModelAndView m = new ModelAndView();
		boolean status = false;
		String name = "";
		Iterable<Customer> list = custrepo.findAll();
		for(Customer customer:list) {
			if(suppRequest.getEmail().equals(customer.getEmail())) {
				status = true;
				name = customer.getFirstname()+customer.getLastname();
			}
		}
		if(status) {
			supprepo.save(suppRequest);
			m.setViewName("response");
			m.addObject("name",name );
		}
		else {
			supprepo.save(suppRequest);
			m.setViewName("registration"); 
		}
		return m;
	}
	
	@RequestMapping(path="/register",method=RequestMethod.POST)
	public ModelAndView processForm(@ModelAttribute("suppRequest") Customer e) {
		ModelAndView m = new ModelAndView();
		custrepo.save(e);
		m.setViewName("response");
		return m;
	}
}
