package com.demo.spring;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;


//@Component
@Aspect
@Order(0)
public class MyLoggerAdvice {
	
	@Pointcut("execution(* com.demo.spring.Perf*.perform(..))")
	private void pcut() {
		
	}
	
	@Before("pcut()")
	public void logBefore() {
		System.out.println("log:before calling");
	}
	@After("pcut()")
	 public void logAfter() {
		 System.out.println("log:after calling");
	 }
}
