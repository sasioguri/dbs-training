package com.demo.spring;


import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class AppMain {
	public static void main(String[] args) {
		//BeanFactory factory = new XmlBeanFactory(new FileSystemResource("C:\\Users\\Abride Solutions\\Documents\\workspace-sts-3.9.9.RELEASE\\spring-app-xml\\src\\main\\resources\\context.xml"));
		//Mail mail=(Mail)factory.getBean("mymail");
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		Performer p = (Performer)ctx.getBean("singer");
		p.perform();
	}
}
