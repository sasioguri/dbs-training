package com.demo.spring;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AudienceAroundAdvice {

	@Around("execution(* com.demo.spring.Perf*.perform(..))")
	public Object invoke(ProceedingJoinPoint pjp) throws Throwable {
		System.out.println("take seats");
		System.out.println("switch off mobiles");
		Object retVal = pjp.proceed();
		System.out.println("clap clap");
		return retVal;
	}
}
