package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.demo.spring.jpa.CustJpaRepository;
import com.demo.spring.jpa.EmpJpaRepository;

@Controller
public class EmpController {
	
	@Autowired
	EmpJpaRepository repo;
	@Autowired
	CustJpaRepository cstrepo;
	
	//@Autowired
	//CusDataValidator validator;
	
	@RequestMapping(path = "/check" ,method = RequestMethod.POST)
	public ModelAndView checkCustomer(@ModelAttribute("suppRequest") SuppRequest suppRequest/*, BindingResult errors*/) {
		
		ModelAndView m = new ModelAndView();
		/*validator.validate(suppRequest, errors);
		if(errors.hasErrors()) {
			m.setViewName("registration");
		}
		else {*/
		boolean status = false;
		String name = "";
		Iterable<Customer> list = cstrepo.findAll();
		
		for(Customer customer:list) {
			System.out.println(customer.getEmail() +":  name"+customer.getFirstname());
			if(suppRequest.getEmail().equals(customer.getEmail())) {
				System.out.println(customer.getFirstname());
				status = true;
				name = customer.getFirstname()+customer.getLastname();
			}
		}
		if(status) {
			repo.save(suppRequest);
			System.out.println("request inserted...");
			m.setViewName("response");
			m.addObject("name",name );
		}
		else {
			m.setViewName("registration"); 
		//	m.addObject(attributeName, attributeValue)
			
		}
		//}
		return m;
	}
	
	
	@RequestMapping(path="/register",method=RequestMethod.POST)
	public ModelAndView processForm(@ModelAttribute("suppRequest") Customer e) {
		ModelAndView m = new ModelAndView();
		cstrepo.save(e);
		m.setViewName("index");
		return m;
	}
	

}
