/*package com.demo.spring;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class CusDataValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(Customer.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		Customer e = (Customer)target;
		if(e.getEmail().isEmpty()) {
			errors.rejectValue("email", "emailEmpty", "Email cannot be empty");
		} if(e.getFirstname().isEmpty()) {
			errors.rejectValue("firstname", "nameEmpty", "name cannot be empty");
		}

	}

}*/
