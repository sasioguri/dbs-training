package com.demo.spring;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Emp {
	
	@Id
	@Column(name="empno")
	private int empid;

	private String name;
	@Column(name="address")
	private String city;
	private double salary;
	public Emp() {
		// TODO Auto-generated constructor stub
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Emp(String name, int empid, String city, double salary) {
		super();
		this.name = name;
		this.empid = empid;
		this.city = city;
		this.salary = salary;
	}
	

}
