package com.demo.spring;


import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class Customer {
	
	private String email;
	private String firstname;	
	private String lastname;	
	private String phonenumber;
	public Customer() {}
	public Customer(String email, String firstname, String lastname, String phonenumber) {
		this.email = email;
		this.firstname = firstname;
		this.lastname = lastname;
		this.phonenumber = phonenumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	

}
