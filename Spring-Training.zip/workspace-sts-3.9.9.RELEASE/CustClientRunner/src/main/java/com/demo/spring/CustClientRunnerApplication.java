package com.demo.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustClientRunnerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustClientRunnerApplication.class, args);
	}

}
