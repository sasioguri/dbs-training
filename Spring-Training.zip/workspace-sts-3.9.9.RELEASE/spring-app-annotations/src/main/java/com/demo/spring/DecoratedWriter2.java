package com.demo.spring;

import org.springframework.stereotype.Component;

@Component
public class DecoratedWriter2 implements Writer{
	public void write(String message) {
		System.out.println("Decorated Writer2 " + message);
	}
}
