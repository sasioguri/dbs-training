package com.demo.spring;

public interface Writer {

	public void write(String message);

}
