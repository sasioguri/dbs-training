package com.demo.spring;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect

public class EmpAdvice {
	@Pointcut("execution(* com.demo.spring.Emp*.registerEmp(..))")
	private void pcut() {
		
	}
	
	@Before("pcut()")
	public void beforeJoining() {
		System.out.println("Before employee joins");
	}
	@After("pcut()")
	public void afterJoining() {
		System.out.println("welcome to office");
	}

}
