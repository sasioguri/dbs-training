package com.demo.spring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;


public class AppMain {
	public static void main(String[] args) {
		//BeanFactory factory = new XmlBeanFactory(new FileSystemResource("C:\\Users\\Abride Solutions\\Documents\\workspace-sts-3.9.9.RELEASE\\spring-app-xml\\src\\main\\resources\\context.xml"));
		//Mail mail=(Mail)factory.getBean("mymail");
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		EmpApp emp = (EmpApp)ctx.getBean("empApp");
		Emp newemp = emp.registerEmp(101,"sasi","ongole",700000);
		System.out.println(emp.save(newemp));
	}
}
