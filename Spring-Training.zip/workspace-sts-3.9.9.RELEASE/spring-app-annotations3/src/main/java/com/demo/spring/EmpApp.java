package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

@Service
public class EmpApp {
	private Emp emp = new Emp();
	public int save(Emp emp) {
		return emp.getEmpId();
	}
	public Emp registerEmp(int id, String name, String city, double salary) {
		emp.setEmpId(id);
		emp.setName(name);
		emp.setCity(city);
		emp.setSalary(salary);
		return emp;
	}
}

